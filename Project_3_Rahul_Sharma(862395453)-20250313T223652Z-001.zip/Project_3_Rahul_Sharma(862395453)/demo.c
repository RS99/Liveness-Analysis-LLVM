#include <stdio.h>

int factorial(int n) {
    if (n <= 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

int power(int base, int exponent) {
    int result = 1;
    for (int i = 0; i < exponent; ++i) {
        result *= base;
    }
    return result;
}

int main() {
    int num1 = 5;
    int num2 = 3;

    printf("Factorial of %d is: %d\n", num1, factorial(num1));
    printf("%d to the power of %d is: %d\n", num1, num2, power(num1, num2));

    return 0;
}
