#cd ./build
#cmake -DLT_LLVM_INSTALL_DIR=/lib/llvm-17 ..
#make 
#cd ..
#The output displayed starts from test0.c to test6.c
echo ""
echo ""
clang -S -fno-discard-value-names -emit-llvm Case_1.c -oCase_1.bc
clang -S -fno-discard-value-names -emit-llvm Case_2.c -oCase_2.bc
clang -S -fno-discard-value-names -emit-llvm Case_3.c -oCase_3.bc
clang -S -fno-discard-value-names -emit-llvm Case_4.c -oCase_4.bc
echo ""
echo "Case_1"
echo ""
opt -load-pass-plugin ./build/lib/libHelloWorld.so -passes=hello-world -disable-output Case_1.bc
echo ""
echo "Case_2"
echo ""
opt -load-pass-plugin ./build/lib/libHelloWorld.so -passes=hello-world -disable-output Case_2.bc
echo ""
echo "Case_3"
echo ""
opt -load-pass-plugin ./build/lib/libHelloWorld.so -passes=hello-world -disable-output Case_3.bc
echo ""
echo "Case_4"
echo ""
opt -load-pass-plugin ./build/lib/libHelloWorld.so -passes=hello-world -disable-output Case_4.bc
