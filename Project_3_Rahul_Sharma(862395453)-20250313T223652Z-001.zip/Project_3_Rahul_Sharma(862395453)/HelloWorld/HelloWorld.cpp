#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Instructions.h"
#include <unordered_map>
#include <unordered_set>
#include <deque>
#include <map>
#include <utility> // for std::pair
#include "llvm/Analysis/PostDominators.h"
using namespace llvm;

//-----------------------------------------------------------------------------
// HelloWorld implementation
//-----------------------------------------------------------------------------
// No need to expose the internals of the pass to the outside world - keep
// everything in an anonymous namespace.
namespace {

struct Info {
  std::set<Value *> gen, kill, in, out;
};
std::map<BasicBlock *, Info> infos;
std::deque<BasicBlock *> worklist;

void visitor(Function &F) {
  // Initialize gen, kill, in, and out sets for each basic block
  for (BasicBlock &BB : F) {
    infos[&BB] = Info();
  }

  bool changed = true;
  while (changed) {
    changed = false;
    // Initialize the worklist with reverse post-order of basic blocks
    for (BasicBlock *BB : post_order(&F.getEntryBlock())) {
      worklist.push_front(BB);
    }

    // Iterate until the worklist is empty
    while (!worklist.empty()) {
      BasicBlock *BB = worklist.front();
      worklist.pop_front();

      // Get the Info for the current basic block
      Info &info = infos[BB];
      std::set<Value *> oldIn = info.in;

      // Calculate gen and kill sets for the current block
      for (auto &I : *BB) {
        if (auto *SI = dyn_cast<StoreInst>(&I)) {
          info.kill.insert(SI->getPointerOperand());
        } else if (auto *LI = dyn_cast<LoadInst>(&I)) {
          Value *V = LI->getPointerOperand();
          if (!info.kill.count(V)) {
            info.gen.insert(V);
          }
        }
      }

      // Calculate the OUT set for the current block
      std::set<Value *> newOut;
      for (BasicBlock *succ : successors(BB)) {
        Info &succInfo = infos[succ];
        newOut.insert(succInfo.in.begin(), succInfo.in.end());
      }

      // Update the IN set for the current block
      info.out = newOut;
      std::set<Value *> newIn = info.gen;
      for (Value *V : newOut) {
        if (!info.kill.count(V)) {
          newIn.insert(V);
        }
      }
      info.in = newIn;

      // Check for changes
      if (newIn != oldIn) {
        changed = true;
      }
    }
  }

  // Print the results after convergence
  for (BasicBlock &BB : F) {
    Info &info = infos[&BB];
    errs() << "----- " << BB.getName() << " -----\n";
    errs() << "UEVAR:";
    for (Value *V : info.gen) {
      errs() << " " << V->getName();
    }
    errs() << "\nVARKILL:";
    for (Value *V : info.kill) {
      errs() << " " << V->getName();
    }
    errs() << "\nLIVEOUT:";
    for (Value *V : info.out) {
      errs() << " " << V->getName();
    }
    errs() << "\n\n";
  }
}


// New PM implementation
struct HelloWorld : PassInfoMixin<HelloWorld> {
  // Main entry point, takes IR unit to run the pass on (&F) and the
  // corresponding pass manager (to be queried if need be)
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
    visitor(F);
    return PreservedAnalyses::all();
  }

  // Without isRequired returning true, this pass will be skipped for functions
  // decorated with the optnone LLVM attribute. Note that clang -O0 decorates
  // all functions with optnone.
  static bool isRequired() { return true; }
};
} // namespace

//-----------------------------------------------------------------------------
// New PM Registration
//-----------------------------------------------------------------------------
llvm::PassPluginLibraryInfo getHelloWorldPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION, "HelloWorld", LLVM_VERSION_STRING,
          [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, FunctionPassManager &FPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                  if (Name == "hello-world") {
                    FPM.addPass(HelloWorld());
                    return true;
                  }
                  return false;
                });
          }};
}

// This is the core interface for pass plugins. It guarantees that 'opt' will
// be able to recognize HelloWorld when added to the pass pipeline on the
// command line, i.e. via '-passes=hello-world'
extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo() {
  return getHelloWorldPluginInfo();
}